import { Tabs } from 'expo-router';
import { Text, View } from 'react-native';

function TabIcon({ label, focused, number }: { label: string; focused: boolean; number: number }) {
  return (
    <View style={{ alignItems: 'center', gap: 4 }}>
      <View style={{
        width: 28, height: 28, borderRadius: 14,
        borderWidth: 1.5,
        borderColor: focused ? '#000' : '#ccc',
        backgroundColor: focused ? '#000' : 'transparent',
        alignItems: 'center', justifyContent: 'center',
      }}>
        <Text style={{ fontSize: 11, color: focused ? '#fff' : '#aaa', fontWeight: '600' }}>{number}</Text>
      </View>
      <Text style={{ fontSize: 11, color: focused ? '#000' : '#aaa', fontWeight: focused ? '600' : '400' }}>{label}</Text>
    </View>
  );
}

export default function RootLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#f5f5f5',
          borderTopWidth: 0,
          height: 80,
          paddingBottom: 16,
          paddingTop: 10,
        },
        tabBarShowLabel: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon label="메인" focused={focused} number={1} />,
        }}
      />
      <Tabs.Screen
        name="feed"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon label="피드" focused={focused} number={2} />,
        }}
      />
      <Tabs.Screen
        name="stats"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon label="통계" focused={focused} number={3} />,
        }}
      />
      <Tabs.Screen
        name="my"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon label="마이" focused={focused} number={4} />,
        }}
      />
      <Tabs.Screen
        name="test"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon label="테스트" focused={focused} number={5} />,
        }}
      />
    </Tabs>
  );
}
