import React, { useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView,
  TextInput, TouchableOpacity, Alert,
} from 'react-native';
import { router } from 'expo-router';
import { signIn } from '../lib/auth';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('알림', '아이디와 비밀번호를 입력해주세요.');
      return;
    }
    setLoading(true);
    const { user, error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      Alert.alert('로그인 실패', '아이디 또는 비밀번호를 확인해주세요.');
      return;
    }
    router.replace('/loading');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <Text style={styles.appName}>ANYWAY</Text>

        <TextInput
          style={styles.input}
          placeholder="아이디"
          placeholderTextColor="#aaa"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <TextInput
          style={styles.input}
          placeholder="비밀번호"
          placeholderTextColor="#aaa"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TouchableOpacity
          style={styles.loginBtn}
          onPress={handleLogin}
          disabled={loading}
        >
          <Text style={styles.loginBtnText}>
            {loading ? '로그인 중...' : '로그인'}
          </Text>
        </TouchableOpacity>

        <View style={styles.bottomLinks}>
          <TouchableOpacity onPress={() => router.push('/signup/step1')}>
            <Text style={styles.linkText}>회원가입</Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={styles.linkText}>아이디/비밀번호 찾기</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  container: {
    flex: 1, paddingHorizontal: 24,
    justifyContent: 'center',
  },
  appName: {
    fontSize: 36, fontWeight: '900',
    textAlign: 'center', marginBottom: 48,
  },
  input: {
    borderWidth: 1, borderColor: '#ddd', borderRadius: 14,
    padding: 18, fontSize: 16, marginBottom: 14, color: '#333',
  },
  loginBtn: {
    backgroundColor: '#e0e0e0', borderRadius: 14,
    padding: 20, alignItems: 'center', marginTop: 8,
  },
  loginBtnText: { fontSize: 16, fontWeight: '700' },
  bottomLinks: {
    flexDirection: 'row', justifyContent: 'flex-end',
    gap: 16, marginTop: 16,
  },
  linkText: { fontSize: 14, color: '#888' },
});
