import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, SafeAreaView,
} from 'react-native';

const FEED_ITEMS = [
  { id: 1, goal: '영어 단어 100개 외우기', anyway: '영어 단어 50개는\n외운 거잖아!', time: '지금' },
  { id: 2, goal: '영어 단어 100개 외우기', anyway: '영어 단어 50개는\n외운 거잖아!', time: '3분 전' },
  { id: 3, goal: '영어 단어 100개 외우기', anyway: '영어 단어 50개는\n외운 거잖아!', time: '54분 전' },
  { id: 4, goal: '영어 단어 100개 외우기', anyway: '영어 단어 50개는\n외운 거잖아!', time: '3시간 전' },
  { id: 5, goal: '영어 단어 100개 외우기', anyway: '영어 단어 50개는\n외운 거잖아!', time: '08:23 AM' },
  { id: 6, goal: '영어 단어 100개 외우기', anyway: '영어 단어 50개는\n외운 거잖아!', time: '06:47 AM' },
];

export default function FeedScreen() {
  const [size, setSize] = useState<'big' | 'small'>('big');

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* 헤더 */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Welcome to ANYWAYS</Text>
          <View style={styles.headerBtns}>
            <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>알림</Text></TouchableOpacity>
            <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>세팅</Text></TouchableOpacity>
          </View>
        </View>

        {/* 큼 / 작음 토글 */}
        <View style={styles.toggleRow}>
          <TouchableOpacity
            style={[styles.toggleBtn, size === 'big' && styles.toggleBtnActive]}
            onPress={() => setSize('big')}
          >
            <Text style={[styles.toggleText, size === 'big' && styles.toggleTextActive]}>큼</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleBtn, size === 'small' && styles.toggleBtnActive]}
            onPress={() => setSize('small')}
          >
            <Text style={[styles.toggleText, size === 'small' && styles.toggleTextActive]}>작음</Text>
          </TouchableOpacity>
        </View>

        {/* 큰 뷰: 세로 리스트 (화면 6) */}
        {size === 'big' && (
          <View>
            {FEED_ITEMS.map((item) => (
              <View key={item.id} style={styles.bigCard}>
                <View style={styles.bigCardImagePlaceholder} />
                <View style={styles.bigCardBottom}>
                  <Text style={styles.bigCardGoal}>{item.goal}</Text>
                  <Text style={styles.bigCardAnyway}>ANYWAY,{'\n'}{item.anyway}</Text>
                  <View style={styles.bigCardMeta}>
                    <View style={styles.pill}><Text style={styles.pillText}>통화</Text></View>
                    <Text style={styles.timeText}>{item.time}</Text>
                  </View>
                  <View style={styles.bigCardActions}>
                    <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>표정</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>공유</Text></TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* 작은 뷰: 2열 그리드 (화면 7) */}
        {size === 'small' && (
          <View style={styles.grid}>
            {FEED_ITEMS.map((item) => (
              <View key={item.id} style={styles.smallCard}>
                <View style={styles.smallCardTop}>
                  <View style={styles.chipRow}>
                    <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>표정</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>공유</Text></TouchableOpacity>
                  </View>
                  <View style={styles.smallCardRight}>
                    <Text style={styles.timeText}>{item.time}</Text>
                    <View style={styles.pill}><Text style={styles.pillText}>통화</Text></View>
                  </View>
                </View>
                <View style={styles.smallCardImagePlaceholder} />
                <Text style={styles.smallCardText}>ANYWAY,{'\n'}{item.anyway}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  headerTitle: { fontSize: 20, fontWeight: '800' },
  headerBtns: { flexDirection: 'row', gap: 8 },
  pill: {
    borderRadius: 20, borderWidth: 1, borderColor: '#ccc',
    paddingHorizontal: 10, paddingVertical: 5, backgroundColor: '#f0f0f0',
  },
  pillText: { fontSize: 12, color: '#555' },
  toggleRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  toggleBtn: {
    borderRadius: 20, borderWidth: 1, borderColor: '#ccc',
    paddingHorizontal: 16, paddingVertical: 7, backgroundColor: '#f0f0f0',
  },
  toggleBtnActive: { backgroundColor: '#000', borderColor: '#000' },
  toggleText: { fontSize: 13, color: '#555', fontWeight: '600' },
  toggleTextActive: { color: '#fff' },
  // 큰 카드
  bigCard: {
    backgroundColor: '#ebebeb', borderRadius: 0, marginBottom: 2, overflow: 'hidden',
  },
  bigCardImagePlaceholder: {
    width: '100%', height: 300, backgroundColor: '#ccc',
  },
  bigCardBottom: { padding: 20 },
  bigCardGoal: { fontSize: 14, color: '#666', marginBottom: 4 },
  bigCardAnyway: { fontSize: 22, fontWeight: '900', lineHeight: 30, marginBottom: 10 },
  bigCardMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  timeText: { fontSize: 13, color: '#888' },
  bigCardActions: { flexDirection: 'row', gap: 8 },
  // 작은 그리드
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  smallCard: {
    width: '47.5%', backgroundColor: '#f0f0f0', borderRadius: 16, padding: 12,
  },
  smallCardTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  smallCardRight: { alignItems: 'flex-end', gap: 4 },
  smallCardImagePlaceholder: {
    width: '100%', height: 120, backgroundColor: '#ccc', borderRadius: 8, marginBottom: 10,
  },
  smallCardText: { fontSize: 15, fontWeight: '800', lineHeight: 22 },
  chipRow: { flexDirection: 'row', gap: 4 },
});
