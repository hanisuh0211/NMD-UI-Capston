import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, SafeAreaView, TextInput, Image,
} from 'react-native';

type Step = 'home' | 'step2' | 'step3' | 'step4' | 'step5';

export default function MainScreen() {
  const [step, setStep] = useState<Step>('home');
  const [goal, setGoal] = useState('');
  const [done, setDone] = useState('');

  // --- 화면 1: 홈 ---
  if (step === 'home') {
    return (
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container}>
          {/* 헤더 */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Tell me your *ANYWAY*</Text>
            <View style={styles.headerBtns}>
              <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>알림</Text></TouchableOpacity>
              <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>세팅</Text></TouchableOpacity>
            </View>
          </View>

          {/* 날짜 & Days */}
          <View style={styles.dateSection}>
            <Text style={styles.dateText}>May 6, 2026</Text>
            <Text style={styles.daysText}>2Days</Text>
          </View>

          {/* 메인 카드 (탭하면 step2로) */}
          <TouchableOpacity style={styles.mainCard} onPress={() => setStep('step2')} activeOpacity={0.85}>
            <View style={styles.avatarPlaceholder} />
            <View style={styles.cardMeta}>
              <View style={styles.pill}><Text style={styles.pillText}>통화</Text></View>
              <Text style={styles.cardDate}>May 6, 2026</Text>
            </View>
            <Text style={styles.cardTitle}>How was your day?</Text>
            <Text style={styles.cardBody}>OO! 오늘은 어떤 걸 할 거야?{'\n'}시간될 때 알려줘!</Text>
            <View style={styles.cardFooter}>
              <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>나중에</Text></TouchableOpacity>
              <Text style={styles.cardFooterLabel}>나중에</Text>
              <View style={{ flex: 1 }} />
              <Text style={styles.cardFooterLabel}>작성</Text>
              <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>작성</Text></TouchableOpacity>
            </View>
          </TouchableOpacity>

          {/* Feed 섹션 */}
          <View style={styles.feedHeader}>
            <Text style={styles.sectionTitle}>Feed</Text>
            <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>화살표</Text></TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.feedItem} activeOpacity={0.8}>
            <View style={styles.feedAvatar} />
            <View style={{ flex: 1 }}>
              <Text style={styles.feedItemTitle}>영어 단어 100개 외우기</Text>
              <Text style={styles.feedItemBody}>ANYWAY, 영어 단어 50개 외웠어!</Text>
            </View>
            <Text style={styles.feedTime}>지금</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // --- 화면 2: 목표 입력 ---
  if (step === 'step2') {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.container}>
          <View style={styles.subHeader}>
            <TouchableOpacity style={styles.pill} onPress={() => setStep('home')}>
              <Text style={styles.pillText}>화살표</Text>
            </TouchableOpacity>
            <Text style={styles.subHeaderTitle}>How was your day?</Text>
            <TouchableOpacity style={styles.pill}>
              <Text style={styles.pillText}>건너뛰기</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.questionCard}>
            <View style={styles.avatarPlaceholder} />
            <View style={styles.cardMeta}>
              <View style={styles.pill}><Text style={styles.pillText}>통화</Text></View>
              <Text style={styles.cardDate}>May 6, 2026</Text>
            </View>
            <Text style={styles.cardTitle}>목표가 뭐였어?</Text>
          </View>

          <TextInput
            style={styles.input}
            placeholder="목표를 입력해 주세요."
            placeholderTextColor="#aaa"
            value={goal}
            onChangeText={setGoal}
          />

          <TouchableOpacity style={styles.bigBtn} onPress={() => setStep('step3')}>
            <Text style={styles.bigBtnText}>작성하기</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // --- 화면 3: 달성 입력 ---
  if (step === 'step3') {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.container}>
          <View style={styles.subHeader}>
            <TouchableOpacity style={styles.pill} onPress={() => setStep('step2')}>
              <Text style={styles.pillText}>화살표</Text>
            </TouchableOpacity>
            <Text style={styles.subHeaderTitle}>How was your day?</Text>
          </View>

          <View style={styles.questionCard}>
            <View style={styles.avatarPlaceholder} />
            <View style={styles.cardMeta}>
              <View style={styles.pill}><Text style={styles.pillText}>통화</Text></View>
              <Text style={styles.cardDate}>May 6, 2026</Text>
            </View>
            <Text style={styles.cardTitle}>어떤 걸 했어?</Text>
          </View>

          <TextInput
            style={styles.input}
            placeholder="달성한 것을 입력해 주세요."
            placeholderTextColor="#aaa"
            value={done}
            onChangeText={setDone}
          />

          <TouchableOpacity style={styles.bigBtn} onPress={() => setStep('step4')}>
            <Text style={styles.bigBtnText}>ANYWAY 생성하기</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // --- 화면 4: ANYWAY 결과 ---
  if (step === 'step4') {
    return (
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.subHeader}>
            <TouchableOpacity style={styles.pill} onPress={() => setStep('step3')}>
              <Text style={styles.pillText}>화살표</Text>
            </TouchableOpacity>
            <Text style={styles.subHeaderTitle}>*ANYWAY*</Text>
          </View>

          <View style={styles.resultCard}>
            <View style={styles.resultCardTop}>
              <View style={styles.avatarPlaceholder} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.resultCardBrand}>ANYWAY</Text>
                <Text style={styles.resultCardSub}>OO, 연속 3일 작성이야. 축하해!{'\n'}ANYWAY 문구를 확인해 봐.</Text>
              </View>
            </View>
            <View style={styles.divider} />
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>GOAL</Text>
              <Text style={styles.resultValue}>{goal || '영어 단어 100개 외우기'}</Text>
            </View>
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>DONE</Text>
              <Text style={styles.resultValue}>{done || '영어 단어 50개 외움'}</Text>
            </View>
            <View style={styles.divider} />
            <Text style={styles.anywayMessage}>영어 단어 50개는 외운 거잖아!{'\n'}그것도 해낸 거지!</Text>
          </View>

          {/* 공개 설정 */}
          <Text style={styles.sectionTitle}>공개 설정</Text>
          <View style={styles.chipRow}>
            {['전체 공개', '친구 공개', '나만 보기'].map(item => (
              <TouchableOpacity key={item} style={styles.chip}>
                <Text style={styles.chipText}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* 표정 설정 */}
          <Text style={styles.sectionTitle}>표정 설정</Text>
          <View style={styles.chipRow}>
            {['최고예요', '멋있어요', '힘내세요', '분발하세요'].map(item => (
              <TouchableOpacity key={item} style={styles.chip}>
                <Text style={styles.chipText}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.chipRow}>
            {['제가 더 못했어요', '기만이에요'].map(item => (
              <TouchableOpacity key={item} style={styles.chip}>
                <Text style={styles.chipText}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity style={[styles.bigBtn, { marginTop: 24 }]} onPress={() => setStep('step5')}>
            <Text style={styles.bigBtnText}>저장하기</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // --- 화면 5: 저장 완료 (메인으로 돌아감) ---
  if (step === 'step5') {
    return (
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>*ANYWAY*</Text>
            <View style={styles.headerBtns}>
              <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>알림</Text></TouchableOpacity>
              <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>세팅</Text></TouchableOpacity>
            </View>
          </View>

          {/* 저장된 카드 */}
          <View style={styles.savedCard}>
            <View style={styles.savedCardHeader}>
              <View style={styles.chipRow}>
                <View style={styles.pill}><Text style={styles.pillText}>3days</Text></View>
                <Text style={{ marginLeft: 8, fontWeight: '500' }}>May 6, 2026</Text>
              </View>
              <View style={styles.chipRow}>
                <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>확장</Text></TouchableOpacity>
                <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>수정</Text></TouchableOpacity>
              </View>
            </View>

            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>GOAL</Text>
              <Text style={styles.resultValue}>{goal || '영어 단어 100개 외우기'}</Text>
            </View>
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>DONE</Text>
              <Text style={styles.resultValue}>{done || '영어 단어 50개 외움'}</Text>
            </View>
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>ANYWAY</Text>
              <Text style={styles.resultValue}>영어 단어 50개는 외운 거잖아!{'\n'}그것도 해낸 거지!</Text>
            </View>

            <View style={[styles.chipRow, { marginTop: 16 }]}>
              <View style={styles.pill}><Text style={styles.pillText}>감정 8</Text></View>
              <View style={styles.pill}><Text style={styles.pillText}>감정 23</Text></View>
              <View style={styles.pill}><Text style={styles.pillText}>감정 0</Text></View>
            </View>
            <View style={[styles.chip, { marginTop: 8, alignSelf: 'flex-start' }]}>
              <Text style={styles.chipText}>힘내라 아자아자~</Text>
            </View>
          </View>

          {/* Feed */}
          <View style={styles.feedHeader}>
            <Text style={styles.sectionTitle}>Feed</Text>
            <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>화살표</Text></TouchableOpacity>
          </View>
          <View style={styles.feedGridRow}>
            {['러닝하러 밖은\n나갔잖아!', '영어 단어 50개는\n외운 거잖아!'].map((txt, i) => (
              <View key={i} style={styles.feedGridCard}>
                <Text style={styles.feedGridBrand}>*Anyway*</Text>
                <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>확장</Text></TouchableOpacity>
                <Text style={styles.feedGridText}>{txt}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  headerTitle: { fontSize: 20, fontWeight: '800' },
  headerBtns: { flexDirection: 'row', gap: 8 },
  pill: {
    borderRadius: 20, borderWidth: 1, borderColor: '#ccc',
    paddingHorizontal: 10, paddingVertical: 5, backgroundColor: '#f0f0f0',
  },
  pillText: { fontSize: 12, color: '#555' },
  dateSection: { alignItems: 'center', marginBottom: 20 },
  dateText: { fontSize: 16, fontWeight: '500', marginBottom: 4 },
  daysText: { fontSize: 64, fontWeight: '900', letterSpacing: -2 },
  mainCard: {
    backgroundColor: '#ebebeb', borderRadius: 20, padding: 20, marginBottom: 28,
  },
  avatarPlaceholder: {
    width: 64, height: 64, borderRadius: 32, backgroundColor: '#ccc',
    marginBottom: 12, alignItems: 'center', justifyContent: 'center',
  },
  cardMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  cardDate: { fontSize: 13, color: '#777' },
  cardTitle: { fontSize: 22, fontWeight: '800', marginBottom: 8 },
  cardBody: { fontSize: 15, color: '#444', lineHeight: 22, marginBottom: 16 },
  cardFooter: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardFooterLabel: { fontSize: 14, color: '#555' },
  feedHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 20, fontWeight: '800', marginBottom: 12 },
  feedItem: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: '#f0f0f0', borderRadius: 16, padding: 16, marginBottom: 10,
  },
  feedAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#ccc' },
  feedItemTitle: { fontSize: 13, color: '#666', marginBottom: 2 },
  feedItemBody: { fontSize: 15, fontWeight: '700' },
  feedTime: { fontSize: 13, color: '#888' },
  // 서브 헤더
  subHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: 28,
  },
  subHeaderTitle: { fontSize: 20, fontWeight: '800', flex: 1, textAlign: 'center' },
  questionCard: { marginBottom: 24 },
  input: {
    backgroundColor: '#ebebeb', borderRadius: 14, padding: 18,
    fontSize: 16, marginBottom: 16, color: '#333',
  },
  bigBtn: {
    backgroundColor: '#e0e0e0', borderRadius: 14, padding: 20,
    alignItems: 'center', marginBottom: 12,
  },
  bigBtnText: { fontSize: 16, fontWeight: '700' },
  // 결과 카드
  resultCard: { backgroundColor: '#ebebeb', borderRadius: 20, padding: 20, marginBottom: 24 },
  resultCardTop: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 16 },
  resultCardBrand: { fontSize: 18, fontWeight: '900', marginBottom: 4 },
  resultCardSub: { fontSize: 13, color: '#555', lineHeight: 20 },
  divider: { height: 1, backgroundColor: '#ccc', marginVertical: 14 },
  resultRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 },
  resultLabel: { fontSize: 15, fontWeight: '800' },
  resultValue: { fontSize: 15, color: '#333', textAlign: 'right', flex: 1, marginLeft: 16 },
  anywayMessage: { fontSize: 17, fontWeight: '800', textAlign: 'center', lineHeight: 26, marginTop: 8 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  chip: { borderRadius: 20, borderWidth: 1, borderColor: '#ccc', paddingHorizontal: 14, paddingVertical: 8 },
  chipText: { fontSize: 14, color: '#333' },
  // 저장된 카드
  savedCard: { backgroundColor: '#ebebeb', borderRadius: 20, padding: 20, marginBottom: 28 },
  savedCardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  feedGridRow: { flexDirection: 'row', gap: 12 },
  feedGridCard: {
    flex: 1, backgroundColor: '#f0f0f0', borderRadius: 16, padding: 14, minHeight: 160,
    justifyContent: 'space-between',
  },
  feedGridBrand: { fontSize: 13, fontWeight: '700', marginBottom: 4 },
  feedGridText: { fontSize: 16, fontWeight: '800', lineHeight: 24, marginTop: 12 },
});
