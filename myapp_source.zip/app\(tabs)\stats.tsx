import React, { useRef, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, SafeAreaView, FlatList, Dimensions,
} from 'react-native';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// 달력 날짜 데이터 (5월 2026)
const MAY_DAYS = Array.from({ length: 31 }, (_, i) => i + 1);
const RECORDED_DAYS = [1, 3, 5, 6, 8, 10, 12, 15, 16, 18, 19, 20, 21, 22, 24, 27];

// 슬라이드 화면 10~13 데이터
const RECAP_SLIDES = [
  {
    key: 'slide1',
    type: 'stats',
    stats: [
      { label: '이번 달 통화 횟수', value: '27' },
      { label: '누적 통화 횟수', value: '182' },
      { label: '이번 달 연속 통화 횟수', value: '16' },
      { label: '최장 연속 통화 횟수', value: '93' },
    ],
  },
  {
    key: 'slide2',
    type: 'compare',
    prev: { label: '4월 연속 통화 횟수', value: '11회' },
    curr: { label: '5월 연속 통화 횟수', value: '16회' },
    message: '이번엔 5일이나 더 만났네!',
    sub: '다음 달도 같이 즐겨보자!',
  },
  {
    key: 'slide3',
    type: 'list',
    items: [
      '그래도 알람은 껐잖아!',
      '그래도 문 밖에는 나섰잖아!',
      '그래도 시작은 했잖아!',
      '그래도 책상 앞에는 앉았잖아!',
      '그래도 뭔갈 빼먹지는 않았잖아!',
      '그래도 포기는 안 했잖아!',
      '그래도 하루 잘 버텨냈잖아!',
    ],
  },
  {
    key: 'slide4',
    type: 'final',
    month: '5월의 Anyway',
    title: '그래도\n시작은 했다',
    stats: [
      { label: '이번 달 통화 횟수', value: '27' },
      { label: '누적 통화 횟수', value: '182' },
      { label: '이번 달 연속 통화 횟수', value: '16' },
      { label: '최장 연속 통화 횟수', value: '93' },
    ],
    message: '이번엔 5일이나 더 만났네!',
    sub: '다음 달도 같이 즐겨보자!',
  },
];

export default function StatsScreen() {
  const [calendarMode, setCalendarMode] = useState<'calendar' | 'list'>('calendar');
  const [showRecap, setShowRecap] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  if (showRecap) {
    return (
      <SafeAreaView style={styles.safe}>
        <FlatList
          ref={flatListRef}
          data={RECAP_SLIDES}
          keyExtractor={(item) => item.key}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => {
            if (item.type === 'stats') {
              return (
                <View style={[styles.slide, { width: SCREEN_WIDTH }]}>
                  {/* 탭 인디케이터 */}
                  <View style={styles.slideIndicator}>
                    {RECAP_SLIDES.map((_, i) => (
                      <View key={i} style={[styles.indicatorDot, i === 0 && styles.indicatorDotActive]} />
                    ))}
                  </View>
                  <View style={styles.statsGrid}>
                    {item.stats!.map((s, i) => (
                      <View key={i} style={styles.statBox}>
                        <Text style={styles.statValue}>{s.value}</Text>
                        <Text style={styles.statLabel}>{s.label}</Text>
                      </View>
                    ))}
                  </View>
                  <View style={styles.chartPlaceholder}>
                    <Text style={styles.chartPlaceholderText}>이번 달 통화 횟수&연속 통화 횟수 vs 본인 평균치{'\n'}그래프 통계</Text>
                  </View>
                </View>
              );
            }

            if (item.type === 'compare') {
              return (
                <View style={[styles.slide, { width: SCREEN_WIDTH }]}>
                  <View style={styles.slideIndicator}>
                    {RECAP_SLIDES.map((_, i) => (
                      <View key={i} style={[styles.indicatorDot, i === 1 && styles.indicatorDotActive]} />
                    ))}
                  </View>
                  <View style={styles.compareRow}>
                    <View style={styles.compareItem}>
                      <Text style={styles.compareLabel}>{item.prev!.label}</Text>
                      <Text style={styles.compareValue}>{item.prev!.value}</Text>
                    </View>
                    <Text style={styles.compareArrow}>›</Text>
                    <View style={styles.compareItem}>
                      <Text style={styles.compareLabel}>{item.curr!.label}</Text>
                      <Text style={styles.compareValue}>{item.curr!.value}</Text>
                    </View>
                  </View>
                  <View style={styles.messageCard}>
                    <Text style={styles.messageIcon}>📞</Text>
                    <View>
                      <Text style={styles.messageBold}>{item.message}</Text>
                      <Text style={styles.messageSub}>{item.sub}</Text>
                    </View>
                  </View>
                  <Text style={styles.collectionTitle}>이번 달 수집 카드</Text>
                  <View style={styles.cardGrid}>
                    {[1,2,3,4,5,6].map(i => (
                      <View key={i} style={styles.collectionCard}>
                        <Text style={styles.collectionCardText}>카드</Text>
                      </View>
                    ))}
                  </View>
                </View>
              );
            }

            if (item.type === 'list') {
              return (
                <View style={[styles.slide, { width: SCREEN_WIDTH }]}>
                  <View style={styles.slideIndicator}>
                    {RECAP_SLIDES.map((_, i) => (
                      <View key={i} style={[styles.indicatorDot, i === 2 && styles.indicatorDotActive]} />
                    ))}
                  </View>
                  <ScrollView>
                    {item.items!.map((txt, i) => (
                      <TouchableOpacity key={i} style={styles.listItem}>
                        <View>
                          <Text style={styles.listItemTime}>00. 00</Text>
                          <Text style={styles.listItemText}>{txt}</Text>
                        </View>
                        <Text style={styles.listArrow}>›</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>
              );
            }

            if (item.type === 'final') {
              return (
                <View style={[styles.slide, { width: SCREEN_WIDTH }]}>
                  <View style={styles.slideIndicator}>
                    {RECAP_SLIDES.map((_, i) => (
                      <View key={i} style={[styles.indicatorDot, i === 3 && styles.indicatorDotActive]} />
                    ))}
                  </View>
                  <View style={{ alignItems: 'center', flex: 1 }}>
                    <View style={styles.finalAvatar} />
                    <Text style={styles.finalMonth}>{item.month}</Text>
                    <Text style={styles.finalTitle}>{item.title}</Text>
                    <View style={styles.statsGrid}>
                      {item.stats!.map((s, i) => (
                        <View key={i} style={styles.statBox}>
                          <Text style={styles.statValue}>{s.value}</Text>
                          <Text style={styles.statLabel}>{s.label}</Text>
                        </View>
                      ))}
                    </View>
                    <View style={styles.messageCard}>
                      <Text style={styles.messageIcon}>📞</Text>
                      <View>
                        <Text style={styles.messageBold}>{item.message}</Text>
                        <Text style={styles.messageSub}>{item.sub}</Text>
                      </View>
                    </View>
                  </View>
                  {/* 하단 버튼 */}
                  <View style={styles.finalFooter}>
                    <TouchableOpacity style={styles.finalIconBtn}><Text>⬇</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.finalIconBtn}><Text>↗</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.confirmBtn} onPress={() => setShowRecap(false)}>
                      <Text style={styles.confirmBtnText}>확인</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            }

            return null;
          }}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* 헤더 */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Your ANYWAY era.</Text>
          <View style={styles.headerBtns}>
            <TouchableOpacity style={styles.iconBtn}><Text style={styles.iconText}>🔔</Text></TouchableOpacity>
            <TouchableOpacity style={styles.iconBtn}><Text style={styles.iconText}>⚙️</Text></TouchableOpacity>
          </View>
        </View>

        {/* 월 네비게이션 */}
        <View style={styles.monthRow}>
          <TouchableOpacity><Text style={styles.monthArrow}>‹</Text></TouchableOpacity>
          <Text style={styles.monthText}>MAY</Text>
          <TouchableOpacity><Text style={styles.monthArrow}>›</Text></TouchableOpacity>
        </View>

        {/* 날짜 + 아이콘 토글 */}
        <View style={styles.dateRow}>
          <Text style={styles.dateLabel}>May 10, 2026</Text>
          <TouchableOpacity
            onPress={() => setCalendarMode(calendarMode === 'calendar' ? 'list' : 'calendar')}
          >
            <Text style={styles.toggleIcon}>{calendarMode === 'calendar' ? '≡' : '📅'}</Text>
          </TouchableOpacity>
        </View>

        {/* 달력 뷰 */}
        {calendarMode === 'calendar' && (
          <View style={styles.calendar}>
            {MAY_DAYS.map((day) => (
              <View
                key={day}
                style={[
                  styles.calendarDay,
                  RECORDED_DAYS.includes(day) && styles.calendarDayRecorded,
                ]}
              >
                <Text style={styles.calendarDayText}>{day}</Text>
              </View>
            ))}
          </View>
        )}

        {/* 리스트 뷰 */}
        {calendarMode === 'list' && (
          <View style={styles.listView}>
            {[
              { title: '영어 단어 50개 외웠어!', goal: '영어 단어 100개 외우기', date: '05/10/26', bold: true },
              { title: '아무 일 없었어', goal: '아무 일 없었어', date: '05/10/26', bold: false },
              { title: '아무 일 없었어', goal: '아무 일 없었어', date: '05/10/26', bold: false },
              { title: '영어 단어 50개 외웠어!', goal: '영어 단어 100개 외우기', date: '05/10/26', bold: true },
              { title: '영어 단어 50개 외웠어!', goal: '영어 단어 100개 외우기', date: '05/10/26', bold: true },
            ].map((item, i) => (
              <View key={i} style={[styles.listCard, item.bold && styles.listCardBold]}>
                <View style={styles.listCardAvatar} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.listCardTitle, item.bold && { fontWeight: '800' }]}>{item.title}</Text>
                  <Text style={styles.listCardGoal}>📞 {item.goal}</Text>
                </View>
                <Text style={styles.listCardDate}>{item.date}</Text>
              </View>
            ))}
            {/* 페이지네이션 */}
            <View style={styles.pagination}>
              {[1,2,3,4,5,6].map(p => (
                <TouchableOpacity key={p} style={[styles.pageBtn, p === 1 && styles.pageBtnActive]}>
                  <Text style={[styles.pageBtnText, p === 1 && styles.pageBtnTextActive]}>{p}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* April Recap 버튼 */}
        <TouchableOpacity style={styles.recapBtn} onPress={() => setShowRecap(true)}>
          <View style={styles.recapAvatar} />
          <View>
            <Text style={styles.recapTitle}>April Recap</Text>
            <Text style={styles.recapSub}>📞 04-2026</Text>
          </View>
          <Text style={styles.recapArrow}>›</Text>
        </TouchableOpacity>

        {/* Statistics */}
        <Text style={styles.statsTitle}>Statistics</Text>
        <View style={styles.statsGrid}>
          {[
            { label: '이번 달 ANYWAY', value: '6' },
            { label: '전체 ANYWAY', value: '3' },
            { label: '이번달 연속', value: '52' },
            { label: '최다 연속', value: '52' },
          ].map((s, i) => (
            <View key={i} style={styles.statBox}>
              <Text style={styles.statLabel}>{s.label}</Text>
              <Text style={styles.statValue}>{s.value}</Text>
            </View>
          ))}
        </View>
        <TouchableOpacity style={styles.compareLink}>
          <Text style={styles.compareLinkText}>지난 달과 비교하기 ›</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  headerTitle: { fontSize: 22, fontWeight: '800' },
  headerBtns: { flexDirection: 'row', gap: 12 },
  iconBtn: { padding: 4 },
  iconText: { fontSize: 20 },
  monthRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  monthArrow: { fontSize: 28, color: '#333', paddingHorizontal: 8 },
  monthText: { fontSize: 48, fontWeight: '900', letterSpacing: -1 },
  dateRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  dateLabel: { fontSize: 16, fontWeight: '600' },
  toggleIcon: { fontSize: 22 },
  // 달력
  calendar: { flexDirection: 'row', flexWrap: 'wrap', gap: 2, marginBottom: 24 },
  calendarDay: {
    width: '12%', aspectRatio: 1, alignItems: 'center', justifyContent: 'center',
    borderRadius: 4, backgroundColor: '#f5f5f5',
  },
  calendarDayRecorded: { backgroundColor: '#ccc' },
  calendarDayText: { fontSize: 13, fontWeight: '500', color: '#333' },
  // 리스트 뷰
  listView: { marginBottom: 24 },
  listCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 16, borderRadius: 12, backgroundColor: '#fff',
    borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  listCardBold: { backgroundColor: '#f5f5f5' },
  listCardAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#ccc' },
  listCardTitle: { fontSize: 15, color: '#333', marginBottom: 2 },
  listCardGoal: { fontSize: 12, color: '#777' },
  listCardDate: { fontSize: 12, color: '#aaa' },
  pagination: { flexDirection: 'row', gap: 8, justifyContent: 'center', marginTop: 16 },
  pageBtn: {
    width: 32, height: 32, borderRadius: 16, borderWidth: 1, borderColor: '#ccc',
    alignItems: 'center', justifyContent: 'center',
  },
  pageBtnActive: { backgroundColor: '#000', borderColor: '#000' },
  pageBtnText: { fontSize: 13, color: '#555' },
  pageBtnTextActive: { color: '#fff' },
  // Recap 버튼
  recapBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 16,
    backgroundColor: '#f0f0f0', borderRadius: 16, padding: 16, marginBottom: 24,
  },
  recapAvatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: '#ccc' },
  recapTitle: { fontSize: 17, fontWeight: '700' },
  recapSub: { fontSize: 13, color: '#777' },
  recapArrow: { fontSize: 22, color: '#888', marginLeft: 'auto' },
  statsTitle: { fontSize: 20, fontWeight: '800', marginBottom: 16 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 12 },
  statBox: {
    width: '47%', backgroundColor: '#f5f5f5', borderRadius: 16,
    padding: 18, alignItems: 'flex-start',
  },
  statLabel: { fontSize: 13, color: '#666', marginBottom: 8 },
  statValue: { fontSize: 36, fontWeight: '900' },
  compareLink: { alignItems: 'flex-end' },
  compareLinkText: { fontSize: 14, color: '#555' },
  // 슬라이드
  slide: { flex: 1, padding: 24, paddingTop: 60 },
  slideIndicator: { flexDirection: 'row', gap: 8, marginBottom: 40, alignSelf: 'center' },
  indicatorDot: { width: 60, height: 4, borderRadius: 2, backgroundColor: '#ddd' },
  indicatorDotActive: { backgroundColor: '#000' },
  // 슬라이드 1 - stats
  chartPlaceholder: {
    backgroundColor: '#f0f0f0', borderRadius: 16, height: 200,
    alignItems: 'center', justifyContent: 'center', marginTop: 20,
  },
  chartPlaceholderText: { fontSize: 13, color: '#aaa', textAlign: 'center' },
  // 슬라이드 2 - compare
  compareRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 32 },
  compareItem: { alignItems: 'center', flex: 1 },
  compareLabel: { fontSize: 13, color: '#888', marginBottom: 8 },
  compareValue: { fontSize: 28, fontWeight: '900' },
  compareArrow: { fontSize: 28, color: '#333', paddingHorizontal: 8 },
  messageCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: '#f0f0f0', borderRadius: 16, padding: 16, marginBottom: 24,
  },
  messageIcon: { fontSize: 24 },
  messageBold: { fontSize: 16, fontWeight: '800' },
  messageSub: { fontSize: 13, color: '#777' },
  collectionTitle: { fontSize: 18, fontWeight: '800', marginBottom: 16 },
  cardGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  collectionCard: {
    width: '30%', aspectRatio: 0.75, backgroundColor: '#ebebeb',
    borderRadius: 12, alignItems: 'center', justifyContent: 'center',
  },
  collectionCardText: { fontSize: 13, color: '#aaa' },
  // 슬라이드 3 - list
  listItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 18, borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  listItemTime: { fontSize: 13, color: '#aaa', marginBottom: 4 },
  listItemText: { fontSize: 18, fontWeight: '800' },
  listArrow: { fontSize: 22, color: '#888' },
  // 슬라이드 4 - final
  finalAvatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#ccc', marginBottom: 12 },
  finalMonth: { fontSize: 15, color: '#888', marginBottom: 8 },
  finalTitle: { fontSize: 40, fontWeight: '900', textAlign: 'center', lineHeight: 48, marginBottom: 32 },
  finalFooter: { flexDirection: 'row', gap: 12, justifyContent: 'flex-end', alignItems: 'center', paddingTop: 16 },
  finalIconBtn: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: '#f0f0f0',
    alignItems: 'center', justifyContent: 'center',
  },
  confirmBtn: {
    backgroundColor: '#e0e0e0', borderRadius: 20, paddingHorizontal: 20, paddingVertical: 12,
  },
  confirmBtnText: { fontSize: 15, fontWeight: '700' },
});
