import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, SafeAreaView,
} from 'react-native';

export default function MyScreen() {
  const [showEdit, setShowEdit] = useState(false);

  if (showEdit) {
    // --- 화면 15: 캐릭터 변경 ---
    return (
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.subHeader}>
            <TouchableOpacity style={styles.pill} onPress={() => setShowEdit(false)}>
              <Text style={styles.pillText}>뒤로가기</Text>
            </TouchableOpacity>
            <Text style={styles.subHeaderTitle}>현재 캐릭터</Text>
          </View>

          {/* 현재 캐릭터 카드 */}
          <View style={styles.currentCard}>
            <View style={styles.currentCardImage} />
            <View style={styles.currentCardInfo}>
              <Text style={styles.userNickname}>유저 닉네임</Text>
              <Text style={styles.characterName}>캐릭터 이름</Text>
              <View style={styles.keywordRow}>
                {['키워드 #1', '키워드 #2', '키워드 #3'].map((kw) => (
                  <View key={kw} style={styles.keywordChip}>
                    <Text style={styles.keywordText}>{kw}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>

          {/* 캐릭터 변경 */}
          <Text style={styles.sectionTitle}>캐릭터 변경</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.characterScroll}>
            {['캐릭터 A', '캐릭터 B', '캐릭터 C'].map((char) => (
              <TouchableOpacity key={char} style={styles.characterOption}>
                <View style={styles.characterKeywords}>
                  {['키워드 #1', '키워드 #2', '키워드 #3'].map((kw) => (
                    <View key={kw} style={styles.keywordChip}>
                      <Text style={styles.keywordText}>{kw}</Text>
                    </View>
                  ))}
                </View>
                <View style={styles.characterImagePlaceholder} />
                <Text style={styles.characterOptionName}>캐릭터 이름</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // --- 화면 14: 마이 프로필 ---
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* 헤더 */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Still you, *ANYWAY*</Text>
          <View style={styles.headerBtns}>
            <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>알림</Text></TouchableOpacity>
            <TouchableOpacity style={styles.pill}><Text style={styles.pillText}>세팅</Text></TouchableOpacity>
          </View>
        </View>

        {/* 프로필 섹션 */}
        <View style={styles.profileRow}>
          <View style={styles.profileAvatar} />
          <View style={{ flex: 1, marginLeft: 16 }}>
            <Text style={styles.userNickname}>유저 닉네임</Text>
            <Text style={styles.characterName}>캐릭터 이름</Text>
            <View style={styles.keywordRow}>
              {['키워드 #1', '키워드 #2', '키워드 #3'].map((kw) => (
                <View key={kw} style={styles.keywordChip}>
                  <Text style={styles.keywordText}>{kw}</Text>
                </View>
              ))}
            </View>
          </View>
          <TouchableOpacity style={styles.editBtn} onPress={() => setShowEdit(true)}>
            <Text style={styles.editBtnText}>수정</Text>
          </TouchableOpacity>
        </View>

        {/* 캐릭터 컨셉샷 */}
        <View style={styles.conceptCard}>
          <Text style={styles.conceptPlaceholder}>캐릭터 컨셉샷</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  headerTitle: { fontSize: 20, fontWeight: '800' },
  headerBtns: { flexDirection: 'row', gap: 8 },
  pill: {
    borderRadius: 20, borderWidth: 1, borderColor: '#ccc',
    paddingHorizontal: 10, paddingVertical: 5, backgroundColor: '#f0f0f0',
  },
  pillText: { fontSize: 12, color: '#555' },
  profileRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 24 },
  profileAvatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#ccc' },
  userNickname: { fontSize: 13, color: '#888', marginBottom: 2 },
  characterName: { fontSize: 22, fontWeight: '800', marginBottom: 8 },
  keywordRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  keywordChip: {
    borderRadius: 16, borderWidth: 1, borderColor: '#ccc',
    paddingHorizontal: 10, paddingVertical: 4, backgroundColor: '#f5f5f5',
  },
  keywordText: { fontSize: 12, color: '#555' },
  editBtn: {
    borderRadius: 16, borderWidth: 1, borderColor: '#ccc',
    paddingHorizontal: 12, paddingVertical: 6, backgroundColor: '#f0f0f0',
  },
  editBtnText: { fontSize: 13, color: '#333' },
  conceptCard: {
    backgroundColor: '#ebebeb', borderRadius: 20, height: 260,
    alignItems: 'center', justifyContent: 'center',
  },
  conceptPlaceholder: { fontSize: 14, color: '#aaa' },
  // 화면 15 스타일
  subHeader: {
    flexDirection: 'row', alignItems: 'center', marginBottom: 24, gap: 12,
  },
  subHeaderTitle: { fontSize: 20, fontWeight: '800' },
  currentCard: {
    backgroundColor: '#ebebeb', borderRadius: 20, overflow: 'hidden', marginBottom: 28,
  },
  currentCardImage: { width: '100%', height: 280, backgroundColor: '#ccc' },
  currentCardInfo: { padding: 20 },
  sectionTitle: { fontSize: 20, fontWeight: '800', marginBottom: 16 },
  characterScroll: { marginHorizontal: -20, paddingLeft: 20 },
  characterOption: {
    width: 180, backgroundColor: '#f0f0f0', borderRadius: 16,
    padding: 14, marginRight: 12,
  },
  characterKeywords: { gap: 4, marginBottom: 10 },
  characterImagePlaceholder: {
    width: '100%', height: 100, backgroundColor: '#ccc', borderRadius: 8, marginBottom: 10,
  },
  characterOptionName: { fontSize: 15, fontWeight: '700', textAlign: 'center' },
});
